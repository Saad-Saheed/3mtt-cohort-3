import { Router } from 'express';
import CustomError from "../helpers/customError.js";
import { isPositiveInteger, isValidNumber, isValidString } from "../helpers/validator.js";
import asyncWrapper from "../middlewares/asyncWrapper.js";
const productRoutes = Router();

// Mock database
let products = [];

const index = asyncWrapper(async (req, res) => {
    res.status(200).json({
        error: false,
        statusCode: 200,
        data: products,
        message: 'Products fetched successfully',
    });
});

const show = asyncWrapper(async (req, res) => {
    const { id } = req.params;

    // Validate the ID parameter
    const productId = parseInt(id);
    if (!isPositiveInteger(productId)) {
        throw new CustomError("Invalid product ID", 400);
    }

    const product = products.find((product) => product.id === productId);

    if (!product) {
        throw new CustomError("Product not found", 404);
    }

    res.status(200).json({
        error: false,
        statusCode: 200,
        data: product,
        message: 'Product fetched successfully',
    });
});

const store = asyncWrapper(async (req, res) => {
    const { name, description, price } = req.body;

    // Validate the request body
    if (!isValidString(name, 3)) {
        throw new CustomError("Name must be a string with at least 3 characters", 400);
    }
    if (!isValidString(description, 10)) {
        throw new CustomError("Description must be a string with at least 10 characters", 400);
    }
    if (!isValidNumber(price)) {
        throw new CustomError("Price must be a positive number", 400);
    }

    const id = products.length + 1;
    const newProduct = {
        id,
        name,
        description,
        price,
    };
    products.push(newProduct);
    res.status(201).json({
        error: false,
        statusCode: 201,
        data: newProduct,
        message: 'Product created successfully',
    });
});

const update = asyncWrapper(async (req, res) => {
    const { id } = req.params;

    // Validate the ID parameter
    const productId = parseInt(id);
    if (!isPositiveInteger(productId)) {
        throw new CustomError("Invalid product ID", 400);
    }

    const { name, description, price } = req.body;
    const productIndex = products.findIndex((product) => product.id === productId);
    if (productIndex === -1) {
        throw new CustomError("Product not found", 404);
    }

    // Validate the request body
    if (name !== undefined && !isValidString(name, 3)) {
        throw new CustomError("Name must be a string with at least 3 characters", 400);
    }
    if (description !== undefined && !isValidString(description, 10)) {
        throw new CustomError("Description must be a string with at least 10 characters", 400);
    }
    if (price !== undefined && !isValidNumber(price)) {
        throw new CustomError("Price must be a positive number", 400);
    }

    // Update the product
    const updatedProduct = {
        ...products[productIndex],
        ...(name !== undefined && { name }),
        ...(description !== undefined && { description }),
        ...(price !== undefined && { price }),
    };
    products[productIndex] = updatedProduct;


    res.status(200).json({
        error: false,
        statusCode: 200,
        data: updatedProduct,
        message: 'Product updated successfully',
    });
});

const destroy = asyncWrapper(async (req, res) => {
    const { id } = req.params;

    // Validate the ID parameter
    const productId = parseInt(id);
    if (!isPositiveInteger(productId)) {
        throw new CustomError("Invalid product ID", 400);
    }

    const productIndex = products.findIndex((product) => product.id === productId);
    if (productIndex === -1) {
        throw new CustomError("Product not found", 404);
    }
    products.splice(productIndex, 1);
    res.status(200).json({
        error: false,
        statusCode: 200,
        data: null,
        message: 'Product deleted successfully',
    });
});

productRoutes.get('/', index);

productRoutes.get('/:id', show);

productRoutes.post('/', store);

productRoutes.patch('/:id', update);

productRoutes.delete('/:id', destroy);

export default productRoutes;
