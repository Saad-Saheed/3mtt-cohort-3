import express from 'express';
import productRoutes from './routes/products.js';
import errorHandler from './middlewares/errorHandler.js';
import CustomError from './helpers/customError.js';

const app = express();
const PORT = 3000;
const HOST = 'localhost';

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.get('/', (req, res) => {
    res.send('Hello, World!');
});
app.use('/api/products', productRoutes);
app.use((req, res) => {
    throw new CustomError(
        'Route not found',
        404,
    );
});
app.use(errorHandler);



app.listen(PORT, () => {
  console.log(`Server is running on http://${HOST}:${PORT}`);
});
